import React from 'react';
import ClickCounter from './ClickCounter';

function App() {
  return (
    <div className="App">
      <ClickCounter />
    </div>
  );
}

export default App;

