import React, { useState } from 'react';
import './ClickCounter.css';

const ClickCounter = () => {
  const [count, setCount] = useState(0);
  const MAX_LIMIT = 10;

  const increase = () => {
    if (count < MAX_LIMIT) setCount(count + 1);
  };

  const decrease = () => {
    if (count > 0) setCount(count - 1);
  };

  return (
    <div className="counter-container">
      <h1>Click Counter App</h1>
      <p className="count-display">Count: {count}</p>
      {count >= MAX_LIMIT && <p className="limit-msg">You've reached the limit!</p>}
      <div className="button-group">
        <button onClick={increase}>Increase</button>
        <button onClick={decrease} disabled={count === 0}>Decrease</button>
      </div>
    </div>
  );
};

export default ClickCounter;
